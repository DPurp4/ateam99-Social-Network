import java.util.Set;

/**
 * 
 */

/**
 * 
 * Defines methods required for an undirected graph
 * 
 * @author Devin DuBeau
 *
 */
public interface GraphADT {
  
  public boolean addEdge(Person p1, Person p2);
  public boolean removeEdge(Person p1, Person p2);
  public boolean addNode(Person p1);
  public boolean removeNode(Person p1);
  public Set<Person> getNeighbors(Person p1);
  public Person getNode(String name);
  public Set<Person> getAllNodes();

}
