import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.MenuBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * 
 */

/**
 * 
 * Defines the GUI of this program and the interaction with the model
 * 
 * @author Devin DuBeau
 *
 */
public class Main extends javafx.application.Application {
  
  public SocialNetwork socialNetwork;
  public VBox signUpBox;
  public VBox twoInputBox;
  public VBox centerBox;
  public VBox bottomBox;
  public MenuBar menuBar;
  
  private void setUpSignUpBox() {}
  private void setUpTwoInputBox() {}
  private void setUpCenterBox() {}
  private void setUpBottomBox() {}
  private void setUpMenuBox() {}
  private void drawGraph(GraphicsContext gc) {}
  private void drawNode(GraphicsContext gc, String name, double x, double y) {}
  private void drawEdge(GraphicsContext gc, double x1, double y1, double x2, double y2) {}
  private String getNameFromCoordinates(double x, double y) { return null; }
  private void setSelectedUser(String name) {}
  
  
  
  


  @Override
  public void start(Stage arg0) throws Exception {
    // TODO Auto-generated method stub
    
  }
  

  /**
   * @param args
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

}
