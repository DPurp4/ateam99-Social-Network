import java.util.HashMap;
import java.util.List;
import java.util.Set;

/**
 * 
 */

/**
 * 
 * Implementation of GraphADT
 * 
 * @author Devin DuBeau
 *
 */
public class Graph implements GraphADT {
  
  private HashMap<Person, List<Person>> adjacencyList;


  @Override
  public boolean addEdge(Person p1, Person p2) {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public boolean removeEdge(Person p1, Person p2) {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public boolean addNode(Person p1) {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public boolean removeNode(Person p1) {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public Set<Person> getNeighbors(Person p1) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Person getNode(String name) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Set<Person> getAllNodes() {
    // TODO Auto-generated method stub
    return null;
  }
  

}
