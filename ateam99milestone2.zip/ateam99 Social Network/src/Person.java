/**
 * 
 */

/**
 * 
 * Defines data and methods for each user

 * @author Devin DuBeau
 *
 */
public class Person {
  
  private String name;
  
  public Person() { }
  
  public Person(String name) {
    this.name = name;
  }

}
