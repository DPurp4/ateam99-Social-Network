README

Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1. Devin DuBeau, LEC 002, ddubeau@wisc.edu
2. Xiaoyuan Liu, LEC 001, xliu798@wisc.edu
3. Yuehan Qin, LEC 001, and yqin43@wisc.edu
4. Reid Chen, LEC 001, and ychen878@wisc.edu
5. Mihir Arora, LEC 001, mrarora@wisc.edu

 

Which team members were on same xteam together?
None

Other notes or comments to the grader: N/A

[place any comments or notes that will help the grader here]